<?php
	include '../../includes/db.php'; 
	echo fetchIndividualInitialData();
?>
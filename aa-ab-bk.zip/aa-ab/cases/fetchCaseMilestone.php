<?php 
	include "../../includes/db.php";

	if ($_POST['caseId']) {
	    $caseId = decrypt($_POST['caseId']);
	    
	    $query = $connect->prepare("SELECT * FROM case_milestones WHERE caseId = ? AND lawFirmId = ? ORDER BY id DESC ");
	    $query->execute([$caseId, $_SESSION['parent_id']]);
	    if($query->rowCount() > 0){
            $milestones = $query->fetchAll();
		    foreach ($milestones as $row) {
		        $addedBy = fetchLawFirmMemberNames($row['userId']);
		        
		        $date = date("D d M Y", strtotime($row['created_at']));
		        
		        $editButton = '';
		        if ($row['userId'] == $_SESSION['user_id']) {
		            $editButton = '<button class="btn btn-primary btn-sm editMilestoneBtn" data-id="' . $row['id'] . '">Edit</button>';
		        }

		        echo '
		            <div class="col-md-12 mb-4">
		                <div class="card">
		                    <div class="card-body">
		                        <h5 class="card-title text-primary">' . htmlspecialchars(decrypt($row['milestoneTitle']), ENT_QUOTES, 'UTF-8') . '</h5>
		                        <p class="card-text">' . htmlspecialchars_decode(decrypt($row['milestoneDescription']), ENT_QUOTES) . '</p>
		                        <p class="card-text"><i class="bi bi-person"></i> ' . htmlspecialchars($addedBy, ENT_QUOTES, 'UTF-8') . ' - ' . $date . ' <em>( <i class="bi bi-clock"></i> ' . time_ago_check($row['created_at']) . ')</em></p>
		                        ' . $editButton . '
		                    </div>
		                </div>
		            </div>
		        ';
		    }
		}else{
			echo "No milestone added yet";
		}
	}
?>
<?php
    include '../../includes/db.php';
    require '../../vendor/autoload.php';
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use setasign\Fpdi\Fpdi;

    $lawFirmId = $_SESSION['parent_id'];

    function fetchClientInfoByForPdf($clientId) {
        global $connect, $lawFirmId;

        try {
            $stmt = $connect->prepare("SELECT * FROM lawFirmClients WHERE id = ? AND lawFirmId = ?");
            $stmt->execute([$clientId, $lawFirmId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($row) {
                if ($row['client_type'] === 'Corporate') {
                    return [
                        'name' => html_entity_decode($row['business_name']),
                        'email' => html_entity_decode(decrypt($row['client_email'])),
                        'Phone' => html_entity_decode(decrypt($row['client_phone'])),
                        'address' => html_entity_decode(decrypt($row['address'])),
                        'type' => 'Corporate'
                    ];
                } else {
                    return [
                        'name' => html_entity_decode(decrypt($row['client_names'])),
                        'email' => html_entity_decode(decrypt($row['client_email'])),
                        'Phone' => html_entity_decode(decrypt($row['client_phone'])),
                        'address' => html_entity_decode(decrypt($row['address'])),
                        'type' => 'Individual'
                    ];
                }
            } else {
                return ['error' => 'No data found for the provided TPIN.'];
            }
        } catch (PDOException $e) {
            return ['error' => 'Database error: ' . $e->getMessage()];
        }
    }

    function savePdfMetadata($lawFirmId, $clientId, $caseId, $caseNo, $filePath, $fileSize) {
        global $connect;
        try {
            $stmt = $connect->prepare("INSERT INTO fee_notes (userId, lawFirmId, clientId, case_id, case_no, file_path, file_size) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $lawFirmId, $clientId, $caseId, $caseNo, $filePath, $fileSize]);
        } catch (PDOException $e) {
            die('Error saving PDF metadata: ' . $e->getMessage());
        }
    }

    function displayCompanyDataPdf($lawFirmId) {
        global $connect;
        try {
            $stmt = $connect->prepare("SELECT * FROM company_info WHERE lawFirmId = ?");
            $stmt->execute([$lawFirmId]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($data) {
                return $data;
            } else {
                return null;
            }
        } catch (PDOException $e) {
            return ['error' => "Database error: " . $e->getMessage()];
        }
    }

    function fetchTimerLogs($caseId, $clientId, $lawFirmId, $startDate = null, $endDate = null) {
        global $connect;
        $sql = "SELECT * FROM `time_entries` 
                WHERE caseId = ? AND clientId = ? AND lawFirmId = ? AND billableStatus = 'Billable'";
        $params = [$caseId, $clientId, $lawFirmId];

        if ($startDate && $endDate) {
            $sql .= " AND dateCreated BETWEEN ? AND ?";
            $params[] = $startDate;
            $params[] = $endDate;
        }

        $stmt = $connect->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function fetchCaseNoByIdPdf($caseId) {
        global $connect;
        try {
            $stmt = $connect->prepare("SELECT case_number FROM cases WHERE id = ?");
            $stmt->execute([$caseId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['case_number'] : null;
        } catch (PDOException $e) {
            return null;
        }
    }

    class FeeNotePDF extends Fpdi {
        private $companyInfo;
        private $clientInfo;
        private $feeNoteDetails;

        public function __construct($companyInfo, $clientInfo, $feeNoteDetails) {
            parent::__construct();
            $this->companyInfo = $companyInfo;
            $this->clientInfo = $clientInfo;
            $this->feeNoteDetails = $feeNoteDetails;
            $this->SetMargins(10, 10, 10);
            $this->AddPage();
        }

        function Header() {
            // Logo
            $logoPath = '../settings/' . $this->companyInfo['logo'];
            try {
                $this->Image($logoPath, 10, 10, 40);
            } catch (Exception $e) {
                $this->SetFont('Arial', 'B', 12);
                $this->SetXY(10, 10);
                $this->Cell(40, 20, 'Logo Error', 1, 0, 'C');
            }

            // Company Name
            $this->SetFont('Arial', 'B', 16);
            $this->SetXY(55, 10);
            $this->Cell(0, 10, $this->companyInfo['company_name'], 0, 1, 'R');

            // Company Details
            $this->SetFont('Arial', '', 10);
            $this->SetXY(55, 20);
            $this->Cell(0, 5, 'TPIN: ' . $this->companyInfo['tpin'], 0, 1, 'R');
            $this->SetX(55);
            $this->Cell(0, 5, $this->companyInfo['address'], 0, 1, 'R');
            $this->SetX(55);
            $this->Cell(0, 5, 'P.O. Box ' . $this->companyInfo['postal_code'], 0, 1, 'R');
            $this->SetX(55);
            $this->Cell(0, 5, $this->companyInfo['telephone'], 0, 1, 'R');
            $this->SetX(55);
            $this->Cell(0, 5, $this->companyInfo['email'], 0, 1, 'R');
            $this->SetX(55);
            $this->Cell(0, 5, $this->companyInfo['website'], 0, 1, 'R');

            // Line separator
            $this->Line(10, 55, 200, 55);

            $this->Ln(10); // Add some space after the header case_no
        }

        function Footer() {
            $this->SetY(-15);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        }

        function AddFeeDetails() {
            $this->SetFont('Arial', 'B', 12);
            $this->Cell(0, 10, 'FEE NOTE', 0, 1, 'C');

            $this->SetFont('Arial', '', 10);
            $this->Cell(0, 5, 'Fee Note #: ' . $this->feeNoteDetails['fee_note_number'], 0, 1);
            $this->Cell(0, 5, 'Date: ' . date('D d M, Y', strtotime($this->feeNoteDetails['date'])), 0, 1);
            $this->Cell(0, 5, 'Due Date: ' . date('D d M, Y', strtotime($this->feeNoteDetails['due_date'])), 0, 1);

            if (!empty($this->feeNoteDetails['start_date']) && !empty($this->feeNoteDetails['end_date'])) {
                $this->Cell(0, 5, 'Period: ' . date('D d M, Y', strtotime($this->feeNoteDetails['start_date'])) . ' to ' . date('D d M, Y', strtotime($this->feeNoteDetails['end_date'])), 0, 1);
            }

            $this->Ln(5);

            $this->SetFont('Arial', 'B', 10);
            $this->Cell(0, 7, 'Bill To:', 0, 1);
            $this->SetFont('Arial', '', 10);
            $this->Cell(0, 5, 'Attention: ' . $this->clientInfo['name'], 0, 1);
            $this->Cell(0, 5, 'Email: ' . $this->clientInfo['email'], 0, 1);
            $this->Cell(0, 5, 'Phone: ' . $this->clientInfo['Phone'], 0, 1);
            $this->MultiCell(0, 5, 'Address: ' . $this->clientInfo['address'], 0, 'L');
            $this->Cell(0, 5, 'Case/File No: ' . $this->clientInfo['caseNo'], 0, 1);

            $this->Ln(10);

            $this->SetFont('Arial', 'B', 10);
            $this->Cell(30, 10, 'Date', 1, 0, 'C');
            $this->Cell(70, 10, 'Task Description', 1, 0, 'C');
            $this->Cell(30, 10, 'Time', 1, 0, 'C');
            $this->Cell(30, 10, 'Hourly Rate', 1, 0, 'C');
            $this->Cell(30, 10, 'Amount', 1, 1, 'C');

            $this->SetFont('Arial', '', 9);
            $total = 0;
            foreach ($this->feeNoteDetails['items'] as $item) {
                $time = sprintf('%02d:%02d', $item['hours'], $item['minutes']);
                $hourlyRate = number_format($item['hourlyRate'], 2);
                $amount = number_format($item['cost'], 2);

                $this->Cell(30, 8, date('D d M, Y', strtotime($item['dateCreated'])), 1);
                $this->Cell(70, 8, $item['description'], 1);
                $this->Cell(30, 8, $time, 1, 0, 'C');
                $this->Cell(30, 8, $hourlyRate, 1, 0, 'R');
                $this->Cell(30, 8, $amount, 1, 1, 'R');
                $total += $item['cost'];
            }

            $this->SetFont('Arial', 'B', 10);
            $this->Cell(160, 10, 'Total', 1, 0, 'R');
            $this->Cell(30, 10, number_format($total, 2), 1, 1, 'R');
        }
    }

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $caseId = $_POST['caseId'];
        $clientId = $_POST['clientId'];
        $clientEmail = $_POST['emailInput'];
        $startDate = $_POST['startDate'] ?? null;
        $endDate = $_POST['endDate'] ?? null;
        $caseNo = fetchCaseNoByIdPdf($caseId);

        // Fetch company info
        $companyInfo = displayCompanyDataPdf($lawFirmId);
        if (isset($companyInfo['error'])) {
            echo json_encode(['success' => false, 'error' => $companyInfo['error']]);
            exit;
        }

        // Fetch client info
        $clientInfo = fetchClientInfoByForPdf($clientId);
        $clientInfo['caseNo'] = $caseNo;

        // Check if there was an error fetching client info
        if (isset($clientInfo['error'])) {
            echo json_encode(['success' => false, 'error' => $clientInfo['error']]);
            exit;
        }

        // Fetch timer logs with date range
        $timerLogs = fetchTimerLogs($caseId, $clientId, $lawFirmId, $startDate, $endDate);

        // Check if there are any timer logs
        if (empty($timerLogs)) {
            echo json_encode(['success' => false, 'error' => 'No billable entries found for the selected date range.']);
            exit;
        }

        // Prepare fee note details
        $feeNoteDetails = [
            'fee_note_number' => 'FN-' . date('Ymd') . '-' . $caseId,
            'date' => date('Y-m-d'),
            'due_date' => date('Y-m-d', strtotime('+30 days')),
            'items' => $timerLogs,
            'start_date' => $startDate,
            'end_date' => $endDate
        ];

        // Create PDF
        $pdf = new FeeNotePDF($companyInfo, $clientInfo, $feeNoteDetails);
        $pdf->AddFeeDetails();

        $fileName = $feeNoteDetails['fee_note_number'] . '.pdf';
        $filePath = 'feenotes/' . $fileName;
        $pdf->Output('F', $filePath);

        $fileSize = filesize($filePath);
        // savePdfMetadata($lawFirmId, $clientId, $caseId, $caseNo, $filePath, $fileSize);
        
        // Send email with attachment
        $emailResult = sendEmailWithAttachment($clientEmail, $filePath, $clientId, $lawFirmId, $startDate, $endDate);
        
        if ($emailResult === true) {
            echo json_encode(['success' => true, 'message' => "The Feenote has been successfully created and sent to $clientEmail."]);
        } else {
            echo json_encode(['success' => false, 'error' => $emailResult]);
        }
    }

    function sendEmailWithAttachment($clientEmail, $pdfFilename, $clientId, $lawFirmId, $startDate, $endDate) {
        $clientNames = getClientNameById($clientId, $lawFirmId);
        $company = fetchCompanyName();
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.zoho.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'support@milatucases.com';
            $mail->Password = 'Javeria##2019'; // Consider using environment variables for credentials
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('support@milatucases.com', 'Feenote');
            $mail->addAddress($clientEmail);

            // Attachments
            $mail->addAttachment($pdfFilename);
            $lawFirmName = $_SESSION['lawFirmName'];
            // Content
            $mail->isHTML(true);
            $mail->Subject = "Your Feenote from $lawFirmName";

            // Personalized email body
            $mail->Body = '
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; }
                    .footer { margin-top: 20px; font-size: 12px; color: #888; }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Dear '.$clientNames.',</h2>
                    <p>We hope this message finds you well.</p>
                    <p>Please find attached the Feenote document for the period from '.date('D d M, Y', strtotime($startDate)).' to '.date('D d M, Y', strtotime($endDate)).'.</p>
                    <p>If you have any questions or need further assistance, feel free to reach out to us.</p>
                    <p>Thank you for your business!</p>
                    <p>Best regards,</p>
                    <div class="footer">
                        '.$company.'
                    </div>
                </div>
            </body>
            </html>';

            $mail->send();
            return true;
        } catch (Exception $e) {
            return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
?>
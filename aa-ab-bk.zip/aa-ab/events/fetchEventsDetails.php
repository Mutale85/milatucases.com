<?php
	
	include("../../includes/db.php");
	if(isset($_POST['eventData'])) {
	    fetchEventDetails(); 
	}
	
?>


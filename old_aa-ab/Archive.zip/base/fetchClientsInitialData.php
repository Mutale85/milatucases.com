<?php
	include '../../includes/db.php'; 
	echo fetchLawFirmClients();
?>
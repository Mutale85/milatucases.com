<footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
    <div class="mb-2 mb-md-0">
        <div class="buy-now">
          
          <div class="btn-buy-now p-3">
              <div id="footer-time">00:00:00</div>
                <div class="action-buttons">
                    <button id="footer-pause" class="btn btn-warning btn-sm" style="display:none;"><i class="bi bi-pause-circle"></i> Pause</button>
                    <button id="footer-start" class="btn btn-success btn-sm" style="display:none;"><i class="bi bi-play-circle"></i> Start</button>
                    <button id="stop-all" class="btn btn-danger btn-sm"><i class="bi bi-stop-circle"></i> Stop </button>
                </div>
            </div>
        </div>
    </div>
  </div>
  
</footer>
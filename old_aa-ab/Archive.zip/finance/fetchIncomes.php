<?php 
	include '../../includes/db.php';
	echo fetchLawFirmIncome($_SESSION['parent_id']);
?>
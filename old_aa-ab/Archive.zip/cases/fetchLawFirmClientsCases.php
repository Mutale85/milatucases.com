<?php 
	include "../../includes/db.php";
	if(isset($_POST['tpin'])){
		$tpin = $_POST['tpin'];
		// displayLawFirmClientsAddedCases($tpin);
	}
?>